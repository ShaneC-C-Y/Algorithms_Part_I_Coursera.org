import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats{
    private double mean;
    private double stddev;
    private double confidenceLo;
    private double confidenceHi;
        
    public PercolationStats(int n, int t){
        if (n < 1 || t < 1)
            throw new IndexOutOfBoundsException("Illegal parameter value.");
        
        Percolation perc = new Percolation(n);

        int row, col;
        double[] count = new double[t];
        for (int i = 0; i < t; i++){
            perc = new Percolation(n);
            while (!perc.percolates()){
                row = StdRandom.uniform(n) + 1;
                col = StdRandom.uniform(n) + 1;
                if (perc.isFull(row, col)){
                    perc.open(row, col);
                    count[i]++;
                }
            }
            count[i] = count[i]/(n*n);
        }
        mean = StdStats.mean(count);
        stddev = StdStats.stddev(count);
        confidenceLo = mean - 0.5*stddev;
        confidenceHi = mean + 0.5*stddev;
    }
    public double mean(){
        return mean;
    }
    
    public double stddev(){
        return stddev;
    }
    
    public double confidenceLo(){
        return confidenceLo;
    }
    
    public double confidenceHi(){
        return confidenceHi;
    }
    
    public static void main(String[] args){
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats percstats = new PercolationStats(n, t);
        
        System.out.printf("mean                    = %.16f\n", 
                          percstats.mean());
        System.out.printf("stddev                  = %.16f\n", 
                          percstats.stddev());
        System.out.printf("95%% confidence interval = %.16f, %.16f \n", 
                          percstats.confidenceLo(), percstats.confidenceHi());
    }
}